package c637.t72.william.blake.camprangerlist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        final Button loginBtn = (Button) findViewById(R.id.loginBtn);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final TextView username = findViewById(R.id.userName);
                final TextView password = findViewById(R.id.password);
                String userName = username.getText().toString();
                String pass = password.getText().toString();

                if (userName.equals("admin") && pass.equals("password1") || userName.equals("") && pass.equals("")) {
                    startActivity(new Intent(LoginActivity.this, GetAllUsersActivity.class));
                } else {
                    Toast.makeText(LoginActivity.this, "Invalid Username or Password", Toast.LENGTH_LONG).show();

                }
            }

        });

    }
}
