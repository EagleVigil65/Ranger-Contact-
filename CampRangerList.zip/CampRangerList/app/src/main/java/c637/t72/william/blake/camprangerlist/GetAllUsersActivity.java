package c637.t72.william.blake.camprangerlist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class GetAllUsersActivity extends AppCompatActivity {
    private ListView listView;
    private ArrayList<Constants> constantsArrayList;
    private CustomAdapter customAdapter;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_all_users);

        listView = (ListView) findViewById(R.id.lv);

        databaseHelper = new DatabaseHelper(this);

        constantsArrayList = databaseHelper.getAllUsers();

        customAdapter = new CustomAdapter(this,constantsArrayList);
        listView.setAdapter(customAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(GetAllUsersActivity.this,UpdateDeleteActivity.class);
                intent.putExtra("user",constantsArrayList.get(position));
                startActivity(intent);
            }
        });

        final Button addRanger = findViewById(R.id.addRanger);
        addRanger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(GetAllUsersActivity.this, MainActivity.class));
            }
        });
    }
}
