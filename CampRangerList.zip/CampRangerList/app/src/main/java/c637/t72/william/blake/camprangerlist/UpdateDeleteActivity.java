package c637.t72.william.blake.camprangerlist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UpdateDeleteActivity extends AppCompatActivity {
    private Constants constants;
    private EditText etUpdateName, etUpdateEmail, etUpdatePhoneNumber;
    private Button btnupdate, btndelete, btnContact;
    private DatabaseHelper databaseHelper;


    boolean isEmailValid(String email) {
        if(email.contains("@")){
            if(email.contains(".com") ||
                    email.contains(".net")||
                    email.contains(".gov") ||
                    email.contains(".org") ||
                    email.contains(".edu")) {
                return true;
            }
        }
        return false;
    }

    boolean isPhoneNumberValid(String phoneNumber){

        Pattern regex = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
        Matcher matcher = regex.matcher(phoneNumber);
        if (matcher.matches()){
            return true;
        } else {
            return false;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_delete);

        Intent intent = getIntent();
        constants = (Constants) intent.getSerializableExtra("user");

        databaseHelper = new DatabaseHelper(this);

        etUpdateName = (EditText) findViewById(R.id.etUpdateName);
        etUpdateEmail = (EditText) findViewById(R.id.etUpdateEmail);
        etUpdatePhoneNumber = (EditText) findViewById(R.id.etUpdatePhoneNumber);

        btnupdate = (Button) findViewById(R.id.btnupdate);
        btnContact = (Button) findViewById(R.id.btnContact);
        btndelete = (Button) findViewById(R.id.btndelete);


        etUpdateName.setText(constants.getName());
        etUpdateEmail.setText(constants.getEmail());
        etUpdatePhoneNumber.setText(constants.getPhoneNumber());




        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = etUpdateEmail.getText().toString().toLowerCase().trim();
                String phoneNumber = etUpdatePhoneNumber.getText().toString().toLowerCase().trim();

                if (isEmailValid(email) && isPhoneNumberValid(phoneNumber)){
                    databaseHelper.updateUser(constants.getId(),etUpdateName.getText().toString(), etUpdateEmail.getText().toString(), etUpdatePhoneNumber.getText().toString());
                    Toast.makeText(UpdateDeleteActivity.this, "Updated Successfully!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(UpdateDeleteActivity.this,MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                } else {
                    Toast.makeText(UpdateDeleteActivity.this, "Please enter a valid phone number or email address", Toast.LENGTH_SHORT).show();
                }

            }
        });

        btndelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelper.deleteUSer(constants.getId());
                Toast.makeText(UpdateDeleteActivity.this, "Deleted Successfully!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(UpdateDeleteActivity.this,MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        btnContact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UpdateDeleteActivity.this, ContactForm.class));
            }
        });

    }
}
