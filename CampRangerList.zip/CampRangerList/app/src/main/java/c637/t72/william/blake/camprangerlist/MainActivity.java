package c637.t72.william.blake.camprangerlist;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    private Button btnStore, btnGetall;
    private EditText etname, etemail, etphonenumber;
    private DatabaseHelper databaseHelper;


    boolean isEmailValid(String email) {
        if(email.contains("@")){
            if(email.contains(".com") ||
                    email.contains(".net")||
                    email.contains(".gov") ||
                    email.contains(".org") ||
                    email.contains(".edu")) {
                return true;
            }
        }
        return false;
    }

    boolean isPhoneNumberValid(String phoneNumber){

        Pattern regex = Pattern.compile("\\d{3}-\\d{3}-\\d{4}");
        Matcher matcher = regex.matcher(phoneNumber);
        if (matcher.matches()){
            return true;
        } else {
            return false;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHelper = new DatabaseHelper(this);

        btnStore = (Button) findViewById(R.id.btnstore);
        btnGetall = (Button) findViewById(R.id.btnget);
        etname = (EditText) findViewById(R.id.etName);
        etemail = (EditText) findViewById(R.id.etEmail);
        etphonenumber = (EditText) findViewById(R.id.etPhoneNumber);



        btnStore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etname.getText().toString().trim();
                String email = etemail.getText().toString().toLowerCase().trim();
                String phoneNumber = etphonenumber.getText().toString().toLowerCase().trim();


                 if(isEmailValid(email) && (isPhoneNumberValid(phoneNumber)) && (etname.length() > 0)){
                    databaseHelper.addUserDetail(name, email, phoneNumber);
                    etname.setText("");
                    etemail.setText("");
                    etphonenumber.setText("");
                    Toast.makeText(MainActivity.this, "Success!", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(MainActivity.this, "Please enter a valid email or phone number!", Toast.LENGTH_SHORT).show();

                }

            }
        });

        btnGetall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GetAllUsersActivity.class);
                startActivity(intent);
            }
        });
    }

}
